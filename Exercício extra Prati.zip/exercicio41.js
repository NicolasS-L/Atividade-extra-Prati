function objetoPessoa() {
    const pessoa = { nome: "Ana", idade: 28 };
    console.log("Idade:", pessoa.idade);
    pessoa.email = "ana@example.com";
    console.log("Objeto atualizado:", pessoa);
}
objetoPessoa();
